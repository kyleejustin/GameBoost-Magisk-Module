#!/system/bin/sh
# common.sh

run_if_exists() {
  [ -x "$1" ] && "$@" || true
}
