#!/system/bin/sh
# service.sh - GameBoost

MODDIR=${0%/*}

# load helper functions if present
[ -f $MODDIR/common.sh ] && . $MODDIR/common.sh

log() { echo "[GameBoost] $1"; }

# safety: detect busybox or toolbox
BB=$(which busybox 2>/dev/null)
if [ -z "$BB" ]; then
  CP="\cp"
else
  CP="$BB cp"
fi

# Example: Set CPU governor to performance (safe-ish)
set_cpu_governor() {
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    gov="$cpu/cpufreq/scaling_governor"
    if [ -f "$gov" ]; then
      echo performance > $gov 2>/dev/null || true
    fi
  done
}

# Example: Raise min scaling freq (adjust values per device)
set_cpu_min_freq() {
  # Example value - 300000 (300 MHz). Be conservative.
  MINFREQ=300000
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    minf="$cpu/cpufreq/scaling_min_freq"
    if [ -f "$minf" ]; then
      echo $MINFREQ > $minf 2>/dev/null || true
    fi
  done
}

# Example: IO scheduler hint
set_io_scheduler() {
  for block in /sys/block/*/queue/scheduler; do
    if [ -f "$block" ]; then
      # try to set noop or mq-deadline (device dependent). We try noop first.
      echo noop > $block 2>/dev/null || echo mq-deadline > $block 2>/dev/null || true
    fi
  done
}

# Example: sysctl tweaks (network, swappiness)
apply_sysctl() {
  # network: reduce tcp latency
  sysctl -w net.ipv4.tcp_timestamps=0 2>/dev/null || true
  sysctl -w vm.swappiness=10 2>/dev/null || true
  sysctl -w vm.vfs_cache_pressure=50 2>/dev/null || true
}

# zram setup (only if device supports and user wants)
enable_zram() {
  if [ -e /sys/block/zram0 ]; then
    echo 1 > /sys/block/zram0/max_comp_streams 2>/dev/null || true
    # allocate 512M (example) - tune based on RAM
    echo $((512 * 1024 * 1024)) > /sys/block/zram0/disksize 2>/dev/null || true
    mkswap /dev/block/zram0 2>/dev/null || true
    swapon -p 5 /dev/block/zram0 2>/dev/null || true
  fi
}

# Apply tweaks
log "Applying GameBoost tweaks..."
set_cpu_governor
set_cpu_min_freq
set_io_scheduler
apply_sysctl
enable_zram

log "GameBoost applied."
