#!/system/bin/sh
# post-fs-data.sh
MODDIR=${0%/*}
# early sysctl
[ -f /system/bin/sysctl ] && /system/bin/sysctl -w vm.swappiness=10 2>/dev/null || true
