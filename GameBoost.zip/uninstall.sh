#!/system/bin/sh
# uninstall.sh
# Try to revert to ondemand or default governor
for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
  gov="$cpu/cpufreq/scaling_governor"
  if [ -f "$gov" ]; then
    echo ondemand > $gov 2>/dev/null || true
  fi
done

# disable zram swap
swapoff -a 2>/dev/null || true
if [ -e /sys/block/zram0 ]; then
  echo 0 > /sys/block/zram0/disksize 2>/dev/null || true
fi
